package pojo;

import javax.persistence.*;



import java.util.Date;
import java.util.List;
public class FilmService {

	protected EntityManager em;
	
	public FilmService(EntityManager em){
		this.em=em;
	}
	
	public Film createFilm(String title,String description,short releaseYear,Album album,String language,List<Actor> actor,List<Category> category,byte rating,Date deleteDate,Date createDate,short length){
		
		//Employee emp = new Employee(id);
		Film film = new Film();
		film.setTitle(title);
		film.setDescription(description);
		film.setReleaseYear(releaseYear);
		film.setAlbum(album);
		film.setLanguage(language);
		film.setActor(actor);
		film.setCategory(category);
		film.setRating(rating);
		film.setLength(length);
		film.setDeleteDate(deleteDate);
		film.setCreateDate(createDate);
		em.persist(film);
		return film;
	}
	
	public Actor createActor(String firstName,String lastName,String gender,Album album,Date deleteDate,Date createDate)
	{
		Actor actor=new Actor();
		actor.setFirstName(firstName);
		actor.setLastName(lastName);
		actor.setGender(gender);
		actor.setCreateDate(createDate);
		actor.setDeleteDate(deleteDate);
		actor.setAlbum(album);
		em.persist(actor);
		return actor;
	}
	
	public Album createAlbum(String albumName,List<Image> image,Date deleteDate,Date createDate)
	{
		Album album=new Album();
		album.setAlbumName(albumName);
		album.setImage(image);
		album.setCreateDate(createDate);
		album.setDeleteDate(deleteDate);
		em.persist(album);
		return album;
		
	}
	public Image createImage(String imageURL,Date deleteDate,Date createDate)
	{
		Image image=new Image();
		image.setImageURL(imageURL);
		image.setCreateDate(createDate);
		image.setDeleteDate(deleteDate);
		em.persist(image);
		return image;
		
	}
	public Category createCategory(String name,Date deleteDate,Date createDate)
	{
		Category catagory=new Category();
		catagory.setName(name);
		catagory.setCreateDate(createDate);
		catagory.setDeleteDate(deleteDate);
		em.persist(catagory);
		return catagory;
		
		
	}

	public Actor findActor(int id) {
		// TODO Auto-generated method stub
		return em.find(Actor.class, id);
	}

	public Category findCategory(int id) {
		// TODO Auto-generated method stub
		return em.find(Category.class, id);
	}

	public Actor setFilmOnACtor(int id,List<Film> film){
		Actor a = findActor(id);
		a.setFilms(film);
		em.persist(a);
		return a;
	}
	public Category setFilmOnCatagory(int id,List<Film> film){
		Category c = findCategory(id);
		c.setFilm(film);
		em.persist(c);
		return c;
	} 


}


